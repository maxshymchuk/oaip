//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TEdit *Edit1;
    TButton *OpenButton;
    TOpenDialog *OpenDialog1;
    TSaveDialog *SaveDialog1;
    TButton *DecodeButton;
    TButton *SaveButton;
    TButton *EncodeButton;
    void __fastcall DecodeButtonClick(TObject *Sender);
    void __fastcall EncodeButtonClick(TObject *Sender);
    void __fastcall OpenButtonClick(TObject *Sender);
    void __fastcall SaveButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
