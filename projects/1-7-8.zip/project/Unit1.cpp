//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include "Unit1.h"
#pragma package(smart_init)
#pragma resource "*.dfm"
//---------------------------------------------------------------------------
TForm1 *Form1;
AnsiString s, s1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
bool CheckLetter(char c)
{
    char glas[10] = {'�','�','�','�','�','�','�','�','�','�'};
    for (int j = 0; j < 10; j++) if (c == glas[j]) return true;
    return false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DecodeButtonClick(TObject *Sender)
{
    s = Edit1->Text;
    s1 = "";
    int i = 1;
    while (i <= s.Length()) {
        if (s[i] == '�' && s[i + 1] == '�') {
            if (i == 1) s1 = s1 + s[i] + s[i + 1];
            else if (!CheckLetter(s[i - 1])) s1 = s1 + s[i] + s[i + 1];
            i++;
        } else s1 = s1 + s[i];
        i++;
    }
    Memo1->Lines->Add(s1);
    Edit1->Text = Memo1->Lines->Strings[Memo1->Lines->Count-1];
}
//---------------------------------------------------------------------------
void __fastcall TForm1::EncodeButtonClick(TObject *Sender)
{
    s = Edit1->Text;
    s1 = "";
    for (int i = 1; i <= s.Length(); i++) {
        s1 = s1 + s[i];
        if (CheckLetter(s[i])) s1 = s1 + "��";
    }
    Memo1->Lines->Add(s1);
    Edit1->Text = Memo1->Lines->Strings[Memo1->Lines->Count-1];
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OpenButtonClick(TObject *Sender)
{
    OpenDialog1->Title="������� ����";
    if (OpenDialog1->Execute())
        Memo1->Lines->LoadFromFile(OpenDialog1->FileName);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SaveButtonClick(TObject *Sender)
{
    SaveDialog1->Title="��������� ����";
    if (SaveDialog1->Execute())
        Memo1->Lines->SaveToFile(SaveDialog1->FileName);
}
//---------------------------------------------------------------------------
