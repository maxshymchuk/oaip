//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <math.h>


#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button1Click(TObject *Sender)
{
 double x, y, r, s, b, h, e;
 int k;
h=0.1;
x=StrToFloat(Edit1->Text);
b=StrToFloat(Edit2->Text);
e=StrToFloat(Edit3->Text);

 while ((x <= b) )
 {
        r = 1;
        s = 0;
        k = 1;
        y=(-0.5*log(1-2*x*cos(M_PI/3)+(x*x)));
  do {
            r *= x;
            s += r*cos(k*M_PI/3.)/k;
            k++;
        } while (fabs(s-y) >= e);
        s-=r;
Memo1->Lines->Add("X=  "+FloatToStr(x));
Memo1->Lines->Add("Summ=   "+FloatToStrF(s,ffFixed, 9, 6));
Memo1->Lines->Add("Y=  "+FloatToStrF(y,ffFixed, 9, 6));
Memo1->Lines->Add("S-Y=  "+FloatToStrF(s-y,ffFixed, 9, 6));
Memo1->Lines->Add("�����=  "+IntToStr(k+1));
Memo1->Lines->Add("___________________");
x+=h;
}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
Memo1->Clear();
}
//---------------------------------------------------------------------------

