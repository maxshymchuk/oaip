//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "time.h"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
int n;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button2Click(TObject *Sender)
{ srand(time(NULL));
n=StrToInt(Edit1->Text);
StringGrid1->ColCount = n;
StringGrid2->ColCount = n;
for (int i = 0; i < n; i++){
StringGrid1->Cells[i][0] = rand()%189-99;
StringGrid2->Cells[i][0] = rand()%189-99;
}
}
//---------------------------------------------------------------------------

bool TForm1::Check(char c[])
{
    for (int i = 0; i < n; i++)
        if (StringGrid2->Cells[i][0] == c) return false;
    return true;
}

void __fastcall TForm1::Button1Click(TObject *Sender)
{
int temp;
for (int i = 0; i < n; i++)
for (int j = 1; j < n; j++)
if (StrToInt(StringGrid1->Cells[j][0]) < StrToInt(StringGrid1->Cells[j - 1][0])) {
   temp = StrToInt(StringGrid1->Cells[j - 1][0]);
   StringGrid1->Cells[j - 1][0] = StringGrid1->Cells[j][0];
   StringGrid1->Cells[j][0] = temp;
}
for (int i = 0; i < n; i++) {
    if (Check(StringGrid1->Cells[i][0].c_str())) {
        ShowMessage(StringGrid1->Cells[i][0] + " ����������� ����� ������� �, �������� ��� � ������� �");
        break;
    }
}

}
//---------------------------------------------------------------------------

