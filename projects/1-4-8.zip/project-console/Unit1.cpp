//---------------------------------------------------------------------------
#pragma argsused
#pragma hdrstop
#include <iostream.h>
#include <iomanip.h>
#include <conio.h>
#include <time.h>
#include <vcl.h>
//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    int *m1, *m2, c, f, d;
    cout << ">> Size of array: ";
    cin >> c;
    d = 2;
    for (int i = c; i >= 100; i /= 10) d++;
    m1 = new int[c];
    m2 = new int[26];
    srand(time(NULL));
    cout << "Array: ";
    for (int i = 0; i < c; i++) {
        m1[i] = rand()%26 + 97;
        m2[m1[i] - 97] += 1;
        cout << setw(d) << (char)m1[i];
    }
    cout << endl;
    cout << "Alpha: ";
    for (int i = 0; i < 26; i++) cout << setw(d) << (char)(i + 97);
    cout << endl;
    cout << "Times: ";
    for (int i = 0; i < 26; i++) cout << setw(d) << m2[i];
    cout << endl;
    cout << ">> Filter: ";
    cin >> f;
    cout << "Answer:";
    for (int i = 0; i < 26; i++) if (m2[i] == f) cout << setw(d) << (char)(i + 97);
    cout << endl;
    system("PAUSE");
    return 0;
}
//---------------------------------------------------------------------------
 