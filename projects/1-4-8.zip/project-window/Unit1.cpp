//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;

int i;
int m[26];
char s[26] = "abcdefghijklmnopqrstuvwxyz";

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
    if (Sender == Button1) {
        for (i=0; i<StringGrid1->ColCount; i++) {
            StringGrid1->Cells[i][0] = s[random(26)];
            if (i <= 26) {
                StringGrid1->Cells[i][2] = s[i];
            }
            StringGrid1->Cells[i][1] = "";
            StringGrid1->Cells[i][3] = "";
            StringGrid1->Cells[i][4] = "";
        }
    }

    if (Sender == Button2) {
        for (i = 0; i < StringGrid1->ColCount; i++) {
            m[i] = 0;
            StringGrid1->Cells[i][3] = "";
            StringGrid1->Cells[i][4] = "";
            StringGrid1->Cells[i][1] = (int)StringGrid1->Cells[i][0][1] - 97;
            m[(int)StringGrid1->Cells[i][0][1] - 97]++;
        }
        for (i = 0; i < StringGrid1->ColCount; i++) StringGrid1->Cells[i][3] = m[i];
    }

    if (Sender == Button4) {
        for (i = 0; i < StringGrid1->ColCount; i++) {
            StringGrid1->Cells[i][4] = "";
            if (StringGrid1->Cells[i][3] == Edit2->Text) {
                StringGrid1->Cells[i][4] = StringGrid1->Cells[i][2];
            }
        }
    }

    if (Sender == Button5) {
        StringGrid1->ColCount = StrToInt(Edit1->Text);
    }
}
//---------------------------------------------------------------------------

