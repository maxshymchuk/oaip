//---------------------------------------------------------------------------
#pragma hdrstop
#pragma argsused
#include <iostream.h>
#include <math>
#include <iomanip.h>
#include <vcl.h>
//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    double x, y, r, s, b, h, e;
    int k;
    cout << "A: ";
    cin >> x;
    cout << "B: ";
    cin >> b;
    cout << "H: ";
    cin >> h;
    cout << "E: ";
    cin >> e;
    cout << setw(8) << "X"
         << setw(12) << "SUM"
         << setw(12) << "FUNC"
         << setw(12) << "DELTA"
         << setw(8) << "STEPS"
         << endl;
    // ��������� ����� ���� double (x <= b)
    while ((x <= b) || (fabs(x - b) < 1e-7)) {
        r = 1;
        s = 1;
        k = 1;
        y = exp(2*x);
        do {
            r *= 2*x/k;
            s += r;
            k++;
        } while (fabs(s-y) >= e);
        s -= r;
        cout << setw(8) << x
             << setw(12) << s
             << setw(12) << y
             << setw(12) << fabs(s-y)
             << setw(8) << k-1
             << endl;
        x += h;
    }
    system("PAUSE");
    return 0;
}
//---------------------------------------------------------------------------
