#include <iostream.h>
#include <math.h>

using namespace std;
double sum = 0;
unsigned int i;

double func_std(unsigned int n) {
	for (n; n > 0; n--) {
		sum = pow(sum+n, 0.5);
	}
	return sum;
}

double func_rec(unsigned int n) {
	if (n == i) {
		return pow(n, 0.5) ;
	}
	return pow(n + func_rec(n + 1), 0.5);
}

int main()
{
	unsigned int n;
	double std, rec;
	cout << "Vvedite n ";
	do {
		cin >> n;
	} while (n < 1);
	i = n;
	std = func_std(n);
	sum = 0;
	n = 1;
	rec = func_rec(n);
	cout << "\n\n" << std << " - otvet standartnii";
	cout << "\n\n" << rec << " - otvet recurentnii\n";
	system("pause");
    return 0;
}

