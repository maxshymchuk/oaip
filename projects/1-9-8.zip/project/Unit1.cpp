//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
#pragma package(smart_init)
#pragma resource "*.dfm"
//---------------------------------------------------------------------------
TForm1 *Form1;
TPoint b1[4], b3[4], b4[4], b5[4], b6[4], b7[4];
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void Move(int xc, int yc)
{
    for (int i = 0; i < 4; i++) {
        b1[i].x += xc;
        b1[i].y += yc;
        b3[i].x += xc;
        b3[i].y += yc;
        b4[i].x += xc;
        b4[i].y += yc;
        b5[i].x += xc;
        b5[i].y += yc;
        b6[i].x += xc;
        b6[i].y += yc;
        b7[i].x += xc;
        b7[i].y += yc;
    }
}
//---------------------------------------------------------------------------
void Redraw()
{
    Form1->Repaint();
    Form1->Canvas->Brush->Color = (TColor)RGB(112, 41, 0);
    Form1->Canvas->Polygon(b1, 3);
    Form1->Canvas->Brush->Color = (TColor)RGB(255, 233, 175);
    Form1->Canvas->Polygon(b3, 3);
    Form1->Canvas->Polygon(b4, 3);
    Form1->Canvas->Polygon(b5, 3);
    Form1->Canvas->Polygon(b6, 3);
    Form1->Canvas->Polygon(b7, 3);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if (Key == VK_LEFT) Move(-20, 0);
    if (Key == VK_RIGHT) Move(20, 0);
    if (Key == VK_UP) Move(0, -20);
    if (Key == VK_DOWN) Move(0, 20);
    Redraw();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    b1[0] = Point(200, 100);
    b1[1] = Point(700, 100);
    b1[2] = Point(730, 500);
    b1[3] = Point(150, 500);
    b3[0] = Point(210, 70);
    b3[1] = Point(450, 100);
    b3[2] = Point(440, 500);
    b3[3] = Point(160, 470);
    b4[0] = Point(230, 50);
    b4[1] = Point(450, 100);
    b4[2] = Point(440, 500);
    b4[3] = Point(180, 450);
    b5[0] = Point(270, 10);
    b5[1] = Point(450, 100);
    b5[2] = Point(440, 500);
    b5[3] = Point(220, 410);
    b6[0] = Point(450, 100);
    b6[1] = Point(690, 90);
    b6[2] = Point(720, 490);
    b6[3] = Point(440, 500);
    b7[0] = Point(450, 100);
    b7[1] = Point(685, 85);
    b7[2] = Point(715, 485);
    b7[3] = Point(440, 500);
    Form1->Canvas->Pen->Color = clBlack;
}
//---------------------------------------------------------------------------

