//---------------------------------------------------------------------------
#include <vcl.h>
#include <vcl/dstring.h>
#pragma hdrstop
#include "Unit1.h"
#pragma package(smart_init)
#pragma resource "*.dfm"
//---------------------------------------------------------------------------
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    for (int i = 1; i <= Edit1->Text.Length(); i++) GetLetter(Edit1->Text, i);
    ListBox1->Items->Add("");
    ListBox2->Items->Add("");
}
//---------------------------------------------------------------------------
AnsiString Fill(int k)
{
    AnsiString s = "";
    for (int i = 1; i < k; i++) s += " ";
    return s;
}
//---------------------------------------------------------------------------
void TForm1::GetLetter(AnsiString s, int c)
{
    ListBox1->Items->Add(s[c]);
    ListBox2->Items->Add(Fill(c) + s[c]);
}
//---------------------------------------------------------------------------

